package com.example.thebudgettracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Dashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Button to navigate to the Set Goals page
        findViewById<Button>(R.id.btn_go_to_goals).setOnClickListener {
            val intent = Intent(this, Set_Goals::class.java)
            startActivity(intent)
        }

        // Button to navigate to the Take and Store Photo page
        findViewById<Button>(R.id.btn_go_to_photos).setOnClickListener {
            val intent = Intent(this, Take_And_Store_Photo::class.java)
            startActivity(intent)
        }

        // Button to navigate to the Manage Categories page
        findViewById<Button>(R.id.btn_go_to_categories).setOnClickListener {
            val intent = Intent(this, Create_Categories::class.java)
            startActivity(intent)
        }

        // Button to navigate to the View Entries page
        findViewById<Button>(R.id.btn_go_to_entries).setOnClickListener {
            val intent = Intent(this, List_Entries::class.java)
            startActivity(intent)
        }

        // Navigate to the Login Page when Exit App is clicked
        findViewById<Button>(R.id.btn_exit_app).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Close the DashboardActivity
        }

        // Other navigation logic for other buttons (already implemented)...
    }
}
