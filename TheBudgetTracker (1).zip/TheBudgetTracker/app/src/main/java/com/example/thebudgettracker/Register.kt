package com.example.thebudgettracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // Submit Registration Button
        findViewById<Button>(R.id.btn_register).setOnClickListener {
            // Perform registration logic here (e.g., save user data to database)

            // Show success message
            Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()

            // Navigate to Login Page
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish() // Optional: Close RegisterActivity so user cannot go back to it
        }
    }
}