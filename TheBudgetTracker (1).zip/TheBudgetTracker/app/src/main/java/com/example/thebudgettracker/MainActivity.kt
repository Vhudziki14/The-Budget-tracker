
package com.example.thebudgettracker

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get references to the UI elements
        val usernameEditText = findViewById<EditText>(R.id.et_username)
        val passwordEditText = findViewById<EditText>(R.id.et_password)
        val loginButton = findViewById<Button>(R.id.btn_login)

        // Handle Login Button Click
        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Perform basic validation (replace with real validation logic)
            if (username == "admin" && password == "password123") {
                // Navigate to Dashboard
                val intent = Intent(this, Dashboard::class.java)
                startActivity(intent)
                // Optionally, finish the LoginActivity so the user can't go back to it
                finish()
            } else {
                // Show error message
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()

                // Handle Register Button Click
                findViewById<Button>(R.id.btn_register).setOnClickListener {
                    val intent = Intent(this, Register::class.java)
                    startActivity(intent)
                }
            }
        }
    }

}