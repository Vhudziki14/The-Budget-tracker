package com.example.thebudgettracker

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class Take_And_Store_Photo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_take_and_store_photo)

        // Back to Dashboard Button
        findViewById<Button>(R.id.btn_back_to_dashboard).setOnClickListener {
            val intent = Intent(this, Dashboard::class.java)
            startActivity(intent)
            finish() // Optional: Close TakeAndStorePhotoActivity
        }
    }
}